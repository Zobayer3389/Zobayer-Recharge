Zobayer Recharge — Android source project (Demo 1.0)

এটি একটি প্রাথমিক Android WebView অ্যাপ প্রজেক্ট। এতে আছে:
- প্রথমবার Super Admin অ্যাকাউন্ট তৈরি
- গ্রাহক/রিসেলার লোকাল রেজিস্ট্রেশন ও লগইন
- ডেমো ব্যালেন্স, রিচার্জ ফর্ম, পেমেন্ট অনুরোধ
- লোকাল লেনদেনের ইতিহাস ও অ্যাডমিন তালিকা

গুরুত্বপূর্ণ সীমাবদ্ধতা:
1) এটি এখনো লাইভ অনলাইন সার্ভিস নয়। ডেটা শুধু ওই ফোনের localStorage-এ থাকে।
2) রিচার্জ করলে কোনো সিমে টাকা/মিনিট যায় না।
3) বিকাশ/নগদ/রকেট থেকে টাকা নেওয়া হয় না।
4) প্রকৃত বহু-ব্যবহারকারী অ্যাপের জন্য নিরাপদ backend, database, OTP authentication,
   admin authorization, payment gateway merchant approval এবং official recharge API দরকার।
5) বাস্তব ব্যবহারের আগে নিরাপত্তা নিরীক্ষা আবশ্যক। এই ডেমোতে পাসওয়ার্ড লোকাল ডেমো ডেটায় রাখা হয়;
   বাস্তব অ্যাপে এভাবে রাখা যাবে না।

APK বানানোর নিয়ম:
- কম্পিউটারে Android Studio ইনস্টল করুন।
- Android Studio থেকে Open নির্বাচন করে এই ZIP extract করা ZobayerRecharge ফোল্ডারটি খুলুন।
- Gradle sync সম্পন্ন হতে দিন (Android Gradle Plugin 8.6.1, compile SDK 35 প্রয়োজন)।
- Build > Build Bundle(s) / APK(s) > Build APK(s) নির্বাচন করুন।
- APK পাওয়া যাবে app/build/outputs/apk/debug/app-debug.apk এ।

প্রথমবার অ্যাপ চালালে আপনার নিজের নাম, ১১ সংখ্যার বাংলাদেশি মোবাইল নম্বর এবং
কমপক্ষে ৬ অক্ষরের পাসওয়ার্ড দিয়ে Super Admin অ্যাকাউন্ট তৈরি করুন।
